import { createContext } from "react";


export  const sizeContext = createContext(100)