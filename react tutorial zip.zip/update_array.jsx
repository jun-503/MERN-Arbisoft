import React, { useState } from 'react';

const initialProducts = [{
  id: 0,
  name: 'Baklava',
  count: 1,
}, {
  id: 1,
  name: 'Cheese',
  count: 5,
}, {
  id: 2,
  name: 'Spaghetti',
  count: 2,
}];

export default function ShoppingCart() {
  const [products, setProducts] = useState(initialProducts);  //////////// Implementing Update

  function handleIncreaseClick(productId) {
    // Create a new array by mapping over the current products
    const updatedProducts = products.map(product => {
      // Find the product with the matching id
      if (product.id === productId) {
        // Return a new object with updated count
        return {
          ...product,
          count: product.count + 1,
        };
      }
      // For other products, return them unchanged
      return product;
    });

    // Update the state with the new array of products
    setProducts(updatedProducts);
  }

  return (
    <ul>
      {products.map(product => (
        <li key={product.id}>
          {product.name} (<b>{product.count}</b>)
          <button onClick={() => {
            handleIncreaseClick(product.id);
          }}>
            +
          </button>
        </li>
      ))}
    </ul>
  );
}
