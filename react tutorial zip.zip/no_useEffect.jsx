/////////////////  Point 1 //////////////////

// When you’re not sure whether some code should be in an Effect or in an event handler, ask yourself why this code needs to run. Use Effects only for code that should run because the component was displayed to the user.

/////////////////// Point 2 ///////////////////////////
//Why useEffect often runs twice

//*****The useEffect hook in React is designed to handle side effects in functional components. The code snippet you provided uses useEffect with an empty dependency array ([]), which means the effect should only run once, when the component mounts.

useEffect(() => {
  loadDataFromLocalStorage();
  checkAuthToken();
}, []);

// Why It Might Run Twice
// ****Strict***** Mode in Development: In React's development mode, React’s Strict Mode intentionally double-invokes certain lifecycle methods (including useEffect) to help detect side effects. This helps ensure that side effects are idempotent (safe to run multiple times). This behavior does not occur in production builds. If you see useEffect running twice, it's likely due to this development-only feature.

// React ****Concurrent**** Mode: React's Concurrent Mode, which is an experimental feature, can also cause effects to be executed more than once to ensure a consistent and performant user experience. This feature is designed to allow React to interrupt and resume rendering, and it can result in effects being run multiple times during development.

// Component Re-renders: If the component that contains useEffect is being re-rendered due to parent component updates or state changes, it might seem like the effect is running multiple times. However, with an empty dependency array, the effect itself should not re-run due to re-renders of the same component.

// Multiple React Instances: Ensure you don’t have multiple copies of React in your project, as this can sometimes lead to unexpected behavior. This can occur if dependencies in node_modules are misaligned or if React is bundled more than once.

// Solution and Verification
// Check Strict Mode: Verify if the behavior persists in production builds. You can do this by running npm run build or yarn build and serving the production build to see if the issue persists.

// Isolate the Issue: If possible, isolate the effect to ensure it's not impacted by other parts of your application or by React's experimental features.

// Development vs. Production: Confirm that the behavior you're observing is specific to development mode by switching to production mode. If the issue is only present in development, it’s most likely due to Strict Mode or Concurrent Mode.

// In summary, if useEffect appears to run twice and it's not due to an actual code issue, it’s likely related to React’s development features or tooling. For production, it should run only once, as intended. 


///////////// Point 3 /////////////////////

// Although it may not ever get remounted in practice in production, following the same constraints in all components makes it easier to move and reuse code. If some logic must run once per app load rather than once per component mount, add a top-level variable to track whether it has already executed:

let didInit = false;

function App() {
  useEffect(() => {
    if (!didInit) {
      didInit = true;
      // ✅ Only runs once per app load
      loadDataFromLocalStorage();
      checkAuthToken();
    }
  }, []);
  // ...
}