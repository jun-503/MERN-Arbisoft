//// We cannot directly access a Child's DOM node using ref. so we use forward ref that gives that provison i.e Escape hatch. Refs are an escape hatch. You should only use them when you have to “step outside React”.


import { forwardRef, useRef } from 'react';

const MyInput = forwardRef((props, ref) => {
  return <input {...props} ref={ref} />;
});

export default function Form() {
  const inputRef = useRef(null);

  function handleClick() {
    inputRef.current.focus();
  }

  return (
    <>
      <MyInput ref={inputRef} />
      <button onClick={handleClick}>
        Focus the input
      </button>
    </>
  );
}
